const MODULE_ID = "drag_test";
const MAX_DISTANCE_UNITS = 30;
Hooks.once("ready", () => {
  const proto = canvas?.tokens?.constructor?.prototype;
  if (!proto) { console.error(`[${MODULE_ID}] TokenLayer unavailable.`); return; }
  if (proto.__dragTest30Installed) { console.warn(`[${MODULE_ID}] Already installed.`); return; }
  const start = proto._onDragLeftStart, move = proto._onDragLeftMove;
  const drop = proto._onDragLeftDrop, cancel = proto._onDragLeftCancel;
  if (typeof start !== "function" || typeof move !== "function") { console.error(`[${MODULE_ID}] Expected TokenLayer drag handlers not found.`); return; }
  proto._onDragLeftStart = function(event, ...args) {
    const result = start.call(this, event, ...args);
    const token = this._draggedToken;
    this._dragTest30Origin = token ? {token, x:Number(token.document?.x ?? token.x), y:Number(token.document?.y ?? token.y)} : null;
    if (this._dragTest30Origin) console.debug(`[${MODULE_ID}] Drag started`, token.document?.name ?? token.name ?? token.id);
    else console.warn(`[${MODULE_ID}] Drag started but _draggedToken is empty.`);
    return result;
  };
  proto._onDragLeftMove = function(event, ...args) { const result = move.call(this, event, ...args); clamp(this); return result; };
  if (typeof drop === "function") proto._onDragLeftDrop = function(event, ...args) { try { clamp(this); return drop.call(this,event,...args); } finally { this._dragTest30Origin=null; } };
  if (typeof cancel === "function") proto._onDragLeftCancel = function(event, ...args) { try { return cancel.call(this,event,...args); } finally { this._dragTest30Origin=null; } };
  proto.__dragTest30Installed = true;
  console.info(`[${MODULE_ID}] Drag limit enabled: ${MAX_DISTANCE_UNITS} scene units.`);
  function clamp(layer) {
    const origin=layer._dragTest30Origin, token=layer._draggedToken ?? origin?.token;
    if (!origin || !token) return;
    const size=Number(canvas.dimensions?.size), units=Number(canvas.scene?.grid?.distance);
    if (!(size>0)||!(units>0)) return;
    const max=MAX_DISTANCE_UNITS*size/units, x0=origin.x, y0=origin.y, x1=Number(token.x), y1=Number(token.y);
    if (![x0,y0,x1,y1].every(Number.isFinite)) return;
    const dx=x1-x0, dy=y1-y0, d=Math.hypot(dx,dy);
    if (d<=max||d===0) return;
    const x=x0+dx*max/d, y=y0+dy*max/d;
    if (token.position?.set) token.position.set(x,y); else {token.x=x;token.y=y;}
    token.refresh?.();
  }
});